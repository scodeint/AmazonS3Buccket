package com.scodeint.awsimageupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AwsImageUploadApplicationTests {

	@Test
	void contextLoads() {
	}

}
